<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Pr3s extends Model
{
    use HasFactory;

    protected $table = 'pr3s'; // Nombre de la tabla en la base de datos

    protected $fillable = ['nom', 'cognoms', 'correu']; // Los campos que se pueden asignar de forma masiva

    public $timestamps = false; // Desactiva las marcas de tiempo
}