<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

<?php $__env->startSection('content'); ?>
<br>
<h1>Llista d'usuaris</h1>
<div class="mt-5">
  <table class="table">
    <thead>
        <tr class="table-primary">
          <th>ID</th>
          <th>Nom</th>
          <th>Tipus</th>
          <th>Email</th>
          <th>Accions sobre la taula</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $dades_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuari): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($usuari->id); ?></td>
            <td><?php echo e($usuari->name); ?></td>
            <td><?php echo e($usuari->tipus); ?></td>
            <td><?php echo e($usuari->email); ?></td>
            <td class="text-left">
                <a href="<?php echo e(route('users.edit', $usuari->id)); ?>" class="btn btn-primary btn-sm">Edita</a>
                <form id="deleteForm" action="<?php echo e(route('users.destroy', $usuari->id)); ?>" method="post" style="display: inline-block">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button id="deleteButton" class="btn btn-danger btn-sm" type="submit">
                        Esborra
                    </button>
                </form>
                <a href="<?php echo e(route('users.show', $usuari->id)); ?>" class="btn btn-info btn-sm">Mostra més</a>
                <a href="<?php echo e(route('pdf.user', $usuari->id)); ?>" class="btn btn-primary btn-sm">Fes-ho PDF</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
<div>

<div class="p-6 bg-white border-b border-gray-200">
    <a href="<?php echo e(url('dashboard')); ?>">Torna al dashboard</a>
</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('disseny', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/empresa/resources/views/llista-users.blade.php ENDPATH**/ ?>