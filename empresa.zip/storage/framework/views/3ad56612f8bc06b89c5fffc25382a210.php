<!DOCTYPE html>
<html>
<head>
    <title>Lista de Usuarios</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            font-size: 10px; /* Ajustar según necesidad */
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid black;
            padding: 6px;
            text-align: left;
        }
        .table-primary {
            background-color: #e9ecef;
        }
    </style>
</head>
<body>
    <h1>Lista de Usuarios</h1>
    <table>
        <thead>
            <tr class="table-primary">
                <td>Nombre</td>
                <td>Email</td>
                <td>Fecha de Creación</td>
                <td>Ultima modificació</td>
            </tr>
        </thead>
        <tbody> 
            <?php if(isset($dades_user)): ?>
            <tr>
                <td><?php echo e($dades_user->name); ?></td>
                <td><?php echo e($dades_user->email); ?></td>
                <td><?php echo e($dades_user->created_at); ?></td>
                <td><?php echo e($dades_user->updated_at); ?></td>
            </tr>
            <?php else: ?>
                <?php $__currentLoopData = $dades_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->created_at); ?></td>
                        <td><?php echo e($user->updated_at); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH /var/www/html/empresa/resources/views/usersPDF.blade.php ENDPATH**/ ?>