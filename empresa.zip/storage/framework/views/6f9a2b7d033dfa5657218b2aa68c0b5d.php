<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

<?php $__env->startSection('content'); ?>
<br>
<h1>Llista de autos</h1>
<div class="mt-5">
  <table class="table">
    <thead>
        <tr class="table-primary">
          <th>Matrícula</th>
          <th>Número de bastidor</th>
          <th>Marca</th>
          <th>Model</th>
          <th>Color</th>
          <th>Nombre de places</th>
          <th>Nombre de portes</th>
          <th>Grandària del maleter</th>
          <th>Tipus de combustible</th>
          <th>Accions sobre la taula</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $dades_autos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $auto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($auto->Matricula_auto); ?></td>
            <td><?php echo e($auto->Número_de_bastidor); ?></td>
            <td><?php echo e($auto->Marca); ?></td>
            <td><?php echo e($auto->Model); ?></td>
            <td><?php echo e($auto->Color); ?></td>
            <td><?php echo e($auto->Nombre_de_places); ?></td>
            <td><?php echo e($auto->Nombre_de_portes); ?></td>
            <td><?php echo e($auto->Grandària_del_maleter); ?></td>
            <td><?php echo e($auto->Tipus_de_combustible); ?></td>
            <td class="text-left">
            <a href="<?php echo e(route('autos.edit', $auto->Matricula_auto)); ?>" class="btn btn-primary btn-sm">Edita</a>
            <form id="deleteForm" action="<?php echo e(route('autos.destroy', $auto->Matricula_auto)); ?>" method="post" style="display: inline-block">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button id="deleteButton" class="btn btn-danger btn-sm" type="submit">
                    Esborra
                </button>
            </form>
            <a href="<?php echo e(route('autos.show', $auto->Matricula_auto)); ?>" class="btn btn-info btn-sm">Mostra més</a>
            <a href="<?php echo e(route('pdf.auto', $auto->Matricula_auto)); ?>" class="btn btn-primary btn-sm">Fes-ho PDF</a> 
        </td>

        <script>
            document.getElementById('deleteForm').addEventListener('submit', function(event) {
                event.preventDefault(); // Evita que se envíe el formulario por defecto

                if (confirm('¿Seguro que deseas borrar este auto?')) {
                    // Si el usuario confirma, envía el formulario
                    this.submit();
                } else {
                    // Si el usuario cancela, no hace nada
                    return false;
                }
            });
        </script>
         
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
<div>
<div class="p-6 bg-white border-b border-gray-200">
<?php if(Auth::user()->tipus == 'capDepartament'): ?>
        <a href="<?php echo e(url('dashboard')); ?>">Torna al dashboard</a>
    <?php else: ?>
        <a href="<?php echo e(url('dashboard-basic')); ?>">Torna al dashboard</a>
    <?php endif; ?>
</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('disseny', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/empresa/resources/views/llista-autos.blade.php ENDPATH**/ ?>