
<?php $__env->startSection('content'); ?>
<div class="card mt-5">
    <div class="card-header">
        Actualització de dades
    </div>
    <div class="card-body">
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        <form method="post" action="<?php echo e(route('user.update', $dades_user->id)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <label for="name">Nom</label>
                <input type="text" class="form-control" name="name" value="<?php echo e($dades_user->name); ?>"/>
            </div>
            <div class="form-group">           
                <label for="email">Email</label>
                <input type="email" class="form-control" name="email" value="<?php echo e($dades_user->email); ?>"/>
            </div>
            <div class="form-group">           
                <label for="tipus">Tipus</label>
                <select name="tipus">
                    <option value="treballador" <?php echo e($dades_user->tipus == 'treballador' ? 'selected' : ''); ?>>Treballador</option>
                    <option value="capDepartament" <?php echo e($dades_user->tipus == 'capDepartament' ? 'selected' : ''); ?>>Cap de Departament</option>
                </select>
            </div>
            <button type="submit" class="btn btn-block btn-primary">Actualitza</button>
        </form>
    </div>
</div>
<br><a href="<?php echo e(url('users')); ?>">Accés directe a la Llista d'Usuaris</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('disseny', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/empresa/resources/views/actualitza-user.blade.php ENDPATH**/ ?>