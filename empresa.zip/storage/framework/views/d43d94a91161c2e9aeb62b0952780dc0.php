<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

<?php $__env->startSection('content'); ?>
<br>
<h1>Llista de clients</h1>
<div class="mt-5">
  <table class="table">
    <thead>
        <tr class="table-primary">
          <th>DNI</th>
          <th>Noms</th>
          <th>Edat</th>
          <th>Telèfon</th>
          <th>Adreça</th>
          <th>Ciutat</th>
          <th>País</th>
          <th>Email</th>
          <th>Accions sobre la taula</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $dades_clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cli): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($cli->DNI); ?></td>
            <td><?php echo e($cli->Noms); ?></td>
            <td><?php echo e($cli->Edat); ?></td>
            <td><?php echo e($cli->Telèfon); ?></td>
            <td><?php echo e($cli->Adreça); ?></td>
            <td><?php echo e($cli->Ciutat); ?></td>
            <td><?php echo e($cli->País); ?></td>
            <td><?php echo e($cli->Email); ?></td>
            <td class="text-left">
            <a href="<?php echo e(route('clients.edit', $cli->DNI)); ?>" class="btn btn-primary btn-sm">Edita</a>
            <form id="deleteForm" action="<?php echo e(route('clients.destroy', $cli->DNI)); ?>" method="post" style="display: inline-block">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button id="deleteButton" class="btn btn-danger btn-sm" type="submit">
                    Esborra
                </button>
            </form>
            <a href="<?php echo e(route('clients.show', $cli->DNI)); ?>" class="btn btn-info btn-sm">Mostra més</a>
            <a href="<?php echo e(route('pdf.client', $cli->DNI)); ?>" class="btn btn-primary btn-sm">Fes-ho PDF</a>
        </td>

        <script>
            document.getElementById('deleteForm').addEventListener('submit', function(event) {
                event.preventDefault(); // Evita que se envíe el formulario por defecto

                if (confirm('¿Seguro que deseas borrar este usuario?')) {
                    // Si el usuario confirma, envía el formulario
                    this.submit();
                } else {
                    // Si el usuario cancela, no hace nada
                    return false;
                }
            });
        </script>
         
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
<div>

<div class="p-6 bg-white border-b border-gray-200">
<?php if(Auth::user()->tipus == 'capDepartament'): ?>
        <a href="<?php echo e(url('dashboard')); ?>">Torna al dashboard</a>
    <?php else: ?>
        <a href="<?php echo e(url('dashboard-basic')); ?>">Torna al dashboard</a>
    <?php endif; ?>
</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('disseny', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/empresa/resources/views/llista-clients.blade.php ENDPATH**/ ?>