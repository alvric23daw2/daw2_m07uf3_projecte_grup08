<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

<?php $__env->startSection('content'); ?>
    <br>
    <h1>Dades del client</h1>
    <div class="mt-5">
        <table class="table table-striped table-bordered table-hover">
            <thead class="thead-dark">
                <tr class="table-primary">
                    <th scope="col">CAMP</th>
                    <th scope="col">VALOR</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>DNI</td>
                    <td><?php echo e($dades_client->DNI); ?></td>
                </tr>
                <tr>
                    <td>Noms</td>
                    <td><?php echo e($dades_client->Noms); ?></td>
                </tr>
                <tr>
                    <td>Edat</td>
                    <td><?php echo e($dades_client->Edat); ?></td>
                </tr>
                <tr>
                    <td>Telèfon</td>
                    <td><?php echo e($dades_client->Telèfon); ?></td>
                </tr>
                <tr>
                    <td>Adreça</td>
                    <td><?php echo e($dades_client->Adreça); ?></td>
                </tr>
                <tr>
                    <td>Ciutat</td>
                    <td><?php echo e($dades_client->Ciutat); ?></td>
                </tr>
                <tr>
                    <td>País</td>
                    <td><?php echo e($dades_client->País); ?></td>
                </tr>
                <tr>
                    <td>Email</td>
                    <td><?php echo e($dades_client->Email); ?></td>
                </tr>
				<tr>
                    <td>Número permís conducció</td>
                    <td><?php echo e($dades_client->Número_permís_conducció); ?></td>
                </tr>
				<tr>
                    <td>Punts del permís de conducció</td>
                    <td><?php echo e($dades_client->Punts_permís_conducció); ?></td>
                </tr>
				<tr>
                    <td>Tipus de targeta</td>
                    <td><?php echo e($dades_client->Tipus_targeta); ?></td>
                </tr>
				<tr>
                    <td>Número targeta</td>
                    <td><?php echo e($dades_client->Número_targeta); ?></td>
                </tr>
            </tbody>
        </table>
        <br>
        <a href="<?php echo e(route('pdf.client', $dades_client->DNI)); ?>" class="btn btn-primary btn-sm">Fes-ho PDF</a>
        <br><br>
        <div class="p-6 bg-white border-b border-gray-200">
        <?php if(Auth::user()->tipus == 'capDepartament'): ?>
        <a href="<?php echo e(url('dashboard')); ?>">Torna al dashboard</a>
    <?php else: ?>
        <a href="<?php echo e(url('dashboard-basic')); ?>">Torna al dashboard</a>
    <?php endif; ?>                
        </div>
        <div class="p-6 bg-white border-b border-gray-200">
            <a href="<?php echo e(url('clients')); ?>">Torna a la llista</a>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('disseny', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/empresa/resources/views/mostra.blade.php ENDPATH**/ ?>