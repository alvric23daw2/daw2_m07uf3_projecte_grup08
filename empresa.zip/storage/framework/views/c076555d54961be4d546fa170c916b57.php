<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

<?php $__env->startSection('content'); ?>
<div class="card mt-5">
  <div class="card-header">
    Afegeix un nou lloguer
  </div>

  <div class="card-body">
    <?php if($errors->any()): ?>
      <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
    <?php endif; ?>
    <form method="post" action="<?php echo e(url('/lloga')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group">           
            <label for="DNI">DNI</label>
            <select name="DNI" class="form-control">
                <option value="">Selecciona un DNI</option>
                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($client->DNI); ?>"><?php echo e($client->DNI); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">           
            <label for="Matricula_auto">Matrícula del vehicle</label>
            <select name="Matricula_auto" class="form-control">
                <option value="">Selecciona una matrícula del vehículo</option>
                <?php $__currentLoopData = $autos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $auto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($auto->Matricula_auto); ?>"><?php echo e($auto->Matricula_auto); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">           
            <label for="Data_del_préstec">Data del préstec</label>
            <input type="date" class="form-control" name="Data_del_préstec"/>
        </div>
        <div class="form-group">           
            <label for="Data_de_devolució">Data de devolució</label>
            <input type="date" class="form-control" name="Data_de_devolució"/>
        </div>
        <div class="form-group">           
            <label for="Lloc_de_devolució">Lloc de devolució</label>
            <input type="text" class="form-control" name="Lloc_de_devolució"/>
        </div>
        <div class="form-group">           
            <label for="Preu_per_dia">Preu per dia</label>
            <input type="number" class="form-control" name="Preu_per_dia"/>
        </div>
        <div class="form-group">           
            <label for="Préstec_amb_retorn_de_dipòsit_ple">Préstec amb retorn de dipòsit ple</label>
            <select class="form-control" name="Préstec_amb_retorn_de_dipòsit_ple">
              <option value="1">Sí</option>
              <option value="0">No</option>    
            </select>
        </div>
        <div class="form-group">           
            <label for="Tipus_d_assegurança">Tipus d'assegurança</label>
            <select name="Tipus_d_assegurança">
                <option value="Franquícia_fins_a_1000_Euros">Franquícia fins a 1000 Euros</option>
                <option value="Franquíca_fins_500_Euros">Franquícia fins a 500 Euros</option>
                <option value="Sense_franquícia">Sense franquícia</option>
            </select>
        </div>
        <button type="submit" class="btn btn-block btn-primary">Envia</button>
    </form>    
  </div>
</div>
<div class="p-6 bg-white border-b border-gray-200">
    <a href="<?php echo e(url('dashboard')); ?>">Torna al dashboard</a>
</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('disseny', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/empresa/resources/views/crear-lloga.blade.php ENDPATH**/ ?>