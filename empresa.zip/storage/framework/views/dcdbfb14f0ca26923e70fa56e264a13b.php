
<?php $__env->startSection('content'); ?>
<h1>Llista d'empleats</h1>
<div class="mt-5">
  <table class="table">
    <thead>
        <tr class="table-primary">
          <td>tid</td>
          <td>Nom</td>
          <td>Cognoms</td>          
          <td>Accions sobre la taula</td>           
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $dades_treballadors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $treb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($treb->tid); ?></td>
            <td><?php echo e($treb->nom); ?></td>
            <td><?php echo e($treb->cognoms); ?></td>                       
            <td class="text-left">
            <a href="<?php echo e(route('trebs.edit', $treb->tid)); ?>" class="btn btn-primary btn-sm">Edita</a>
            <form action="<?php echo e(route('trebs.destroy', $treb->tid)); ?>" method="post" style="display: inline-block">
              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>
              <button class="btn btn-danger btn-sm" type="submit">
                Esborra
              </button>
            </form>
            <a href="<?php echo e(route('trebs.show', $treb->tid)); ?>" class="btn btn-info btn-sm">Mostra</a>  
          </td>            
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
<div>
<div class="p-6 bg-white border-b border-gray-200">
	<a href="<?php echo e(url('dashboard')); ?>">Torna al dashboard<a/>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('disseny', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/empresa/resources/views/llista2.blade.php ENDPATH**/ ?>