
<?php $__env->startSection('content'); ?>
    <br>
    <h1>Dades de l'usuari</h1>
    <div class="mt-5">
        <table class="table table-striped table-bordered table-hover">
            <thead class="thead-dark">
                <tr class="table-primary">
                    <th scope="col">CAMP</th>
                    <th scope="col">VALOR</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>ID</td>
                    <td><?php echo e($dades_user->id); ?></td>
                </tr>
                <tr>
                    <td>Nom</td>
                    <td><?php echo e($dades_user->name); ?></td>
                </tr>
                <tr>
                    <td>Tipus</td>
                    <td><?php echo e($dades_user->tipus); ?></td>
                </tr>
                <tr>
                    <td>Email</td>
                    <td><?php echo e($dades_user->email); ?></td>
                </tr>
                <tr>
                    <td>Data de creació</td>
                    <td><?php echo e($dades_user->created_at); ?></td>
                </tr>
                <tr>
                    <td>Data d'actualització</td>
                    <td><?php echo e($dades_user->updated_at); ?></td>
                </tr>
            </tbody>
        </table>
        <br>
        <div class="p-6 bg-white border-b border-gray-200">
        <?php if(Auth::user()->tipus == 'capDepartament'): ?>
        <a href="<?php echo e(url('dashboard')); ?>">Torna al dashboard</a>
    <?php else: ?>
        <a href="<?php echo e(url('dashboard-basic')); ?>">Torna al dashboard</a>
    <?php endif; ?>                  
        </div>
        <div class="p-6 bg-white border-b border-gray-200">
            <a href="<?php echo e(url('users')); ?>">Torna a la llista d'usuaris</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('disseny', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/empresa/resources/views/mostra-usuario.blade.php ENDPATH**/ ?>