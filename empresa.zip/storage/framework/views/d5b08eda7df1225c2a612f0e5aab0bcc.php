
<?php $__env->startSection('content'); ?>
<h1>Dades del treballador</h1>
<div class="mt-5">
<table class="table table-striped table-bordered table-hover">
<thead class="thead-dark">
<tr class="table-primary">
<th scope="col">CAMP</td>
<th scope="col">VALOR</td>
</tr>
</thead>
<tbody>
<tr>
<td>tid</td>
<td><?php echo e($dades_treballador->tid); ?></td>
</tr>
<tr>
<td>Nom</td>
<td><?php echo e($dades_treballador->nom); ?></td>
</tr>
<tr>
<td>Cognoms</td>
<td><?php echo e($dades_treballador->cognoms); ?></td>
</tr>
<tr>
<td>Categoria</td>
<td><?php echo e($dades_treballador->categoria); ?></td>
</tr>
<tr>
<td>Nom de la feina</td>
<td><?php echo e($dades_treballador->nom_feina); ?></td>
</tr>
</tbody>
</table>
<div class="p-6 bg-white border-b border-gray-200">
<a href="<?php echo e(url('dashboard-basic')); ?>">Torna al dashboard<a/>
</div>
<div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('disseny', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/empresa/resources/views/mostra-basica.blade.php ENDPATH**/ ?>