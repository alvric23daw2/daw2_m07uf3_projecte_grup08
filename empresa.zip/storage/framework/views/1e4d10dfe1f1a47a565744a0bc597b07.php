<!DOCTYPE html>
<html>
<head>
    <title>Llista d'Autos</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            font-size: 10px; /* Ajustar según necesidad */
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid black;
            padding: 6px;
            text-align: left;
        }
        .table-primary {
            background-color: #e9ecef;
        }
    </style>
</head>
<body>
    <h1>Llista d'Autos</h1>
    <table>
        <thead>
            <tr class="table-primary">
                <td>Matricula_auto</td>
                <td>Número_de_bastidor</td>
                <td>Marca</td>
                <td>Model</td>
                <td>Color</td>
                <td>Nombre_de_places</td>
                <td>Nombre_de_portes</td>
                <td>Grandària_del_maleter</td>
                <td>Tipus_de_combustible</td>
            </tr>
        </thead>
        <tbody> 
            <?php if(isset($dades_auto)): ?>   
                <tr>
                    <td><?php echo e($dades_auto->Matricula_auto); ?></td>
                    <td><?php echo e($dades_auto->Número_de_bastidor); ?></td>
                    <td><?php echo e($dades_auto->Marca); ?></td>
                    <td><?php echo e($dades_auto->Model); ?></td>
                    <td><?php echo e($dades_auto->Color); ?></td>
                    <td><?php echo e($dades_auto->Nombre_de_places); ?></td>
                    <td><?php echo e($dades_auto->Nombre_de_portes); ?></td>
                    <td><?php echo e($dades_auto->Grandària_del_maleter); ?></td>
                    <td><?php echo e($dades_auto->Tipus_de_combustible); ?></td>
                </tr>
            <?php else: ?>
                <?php $__currentLoopData = $dades_auto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $auto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($auto->Matricula_auto); ?></td>
                    <td><?php echo e($auto->Número_de_bastidor); ?></td>
                    <td><?php echo e($auto->Marca); ?></td>
                    <td><?php echo e($auto->Model); ?></td>
                    <td><?php echo e($auto->Color); ?></td>
                    <td><?php echo e($auto->Nombre_de_places); ?></td>
                    <td><?php echo e($auto->Nombre_de_portes); ?></td>
                    <td><?php echo e($auto->Grandària_del_maleter); ?></td>
                    <td><?php echo e($auto->Tipus_de_combustible); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
</tbody>
    </table>
</body>
</html>
<?php /**PATH /var/www/html/empresa/resources/views/autosPDF.blade.php ENDPATH**/ ?>