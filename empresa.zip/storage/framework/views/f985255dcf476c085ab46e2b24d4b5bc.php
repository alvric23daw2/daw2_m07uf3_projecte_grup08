
<?php $__env->startSection('content'); ?>
    <h1>Llista d'usuaris</h1>
    <div class="mt-5">
        <table class="table table-striped table-bordered table-hover">
            <thead>
                <tr class="table-primary">
                    <td>ID</td>
                    <td>Nom</td>
                    <td>Email</td>
                    <td>Accions sobre la taula</td>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $dades_usuaris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuari): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($usuari->id); ?></td>
                        <td><?php echo e($usuari->name); ?></td>
                        <td><?php echo e($usuari->email); ?></td>
                        <td class="text-left">
                            <a href="<?php echo e(route('usuaris.show_basic', $usuari->id)); ?>" class="btn btn-info btn-sm">Mostra</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="p-6 bg-white border-b border-gray-200">
            <a href="<?php echo e(url('dashboard-basic')); ?>">Torna al dashboard</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('disseny', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/empresa/resources/views/llista-basica.blade.php ENDPATH**/ ?>