<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

<?php $__env->startSection('content'); ?>
<div class="card mt-5">
    <div class="card-header">
        Actualització de dades
    </div>
    <div class="card-body">
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        <form method="post" action="<?php echo e(route('autos.update', $dades_auto->Matricula_auto)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <div class="form-group">
                <label for="Matricula_auto">Matrícula</label>
                <input type="text" class="form-control" name="Matricula_auto" value="<?php echo e($dades_auto->Matricula_auto); ?>"/>
            </div>
            <div class="form-group">           
                <label for="Número_de_bastidor">Número de bastidor</label>
                <input type="text" class="form-control" name="Número_de_bastidor" value="<?php echo e($dades_auto->Número_de_bastidor); ?>"/>
            </div>
            <div class="form-group">           
                <label for="Marca">Marca</label>
                <input type="text" class="form-control" name="Marca" value="<?php echo e($dades_auto->Marca); ?>"/>
            </div>
            <div class="form-group">           
                <label for="Model">Model</label>
                <input type="text" class="form-control" name="Model" value="<?php echo e($dades_auto->Model); ?>"/>
            </div>
            <div class="form-group">           
                <label for="Color">Color</label>
                <input type="text" class="form-control" name="Color" value="<?php echo e($dades_auto->Color); ?>"/>
            </div>
            <div class="form-group">           
                <label for="Nombre_de_places">Número de plazas</label>
                <input type="number" class="form-control" name="Nombre_de_places" value="<?php echo e($dades_auto->Nombre_de_places); ?>"/>
            </div>
            <div class="form-group">           
                <label for="Nombre_de_portes">Número de puertas</label>
                <input type="number" class="form-control" name="Nombre_de_portes" value="<?php echo e($dades_auto->Nombre_de_portes); ?>"/>
            </div>
            <div class="form-group">           
                <label for="Grandària_del_maleter">Tamaño del maletero</label>
                <input type="text" class="form-control" name="Grandària_del_maleter" value="<?php echo e($dades_auto->Grandària_del_maleter); ?>"/>
            </div>
            <div class="form-group">           
                <label for="Tipus_de_combustible">Tipo de combustible</label>
                <select name="Tipus_de_combustible">
                    <option value="gasolina" <?php echo e($dades_auto->Tipus_de_combustible == 'gasolina' ? 'selected' : ''); ?>>Gasolina</option>
                    <option value="diesel" <?php echo e($dades_auto->Tipus_de_combustible == 'diesel' ? 'selected' : ''); ?>>Diésel</option>
                    <option value="elèctric" <?php echo e($dades_auto->Tipus_de_combustible == 'elèctric' ? 'selected' : ''); ?>>Eléctrico</option>
                </select>
            </div>
            <button type="submit" class="btn btn-block btn-primary">Actualitza</button>
        </form>
    </div>
</div>
<br><a href="<?php echo e(url('autos')); ?>">Accés directe a la Llista d'Autos</a>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('disseny', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/empresa/resources/views/actualitza-cotxes.blade.php ENDPATH**/ ?>