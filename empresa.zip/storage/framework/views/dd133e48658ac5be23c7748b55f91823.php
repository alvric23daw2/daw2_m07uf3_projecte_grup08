
<?php $__env->startSection('content'); ?>
<div class="card mt-5">
  <div class="card-header">
    Afegeix un nou usuari
  </div>

  <div class="card-body">
    <?php if($errors->any()): ?>
      <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
    <?php endif; ?>
    <form method="post" action="<?php echo e(url('/users')); ?>">
        <?php echo csrf_field(); ?>
        <!-- https://laravel.com/docs/10.x/csrf -->
        <div class="form-group">           
            <label for="name">Nom</label>
            <input type="text" class="form-control" name="name"/>
        </div>
        <div class="form-group">           
            <label for="tipus">Tipus</label>
            <select name="tipus">
                <option value="treballador">Treballador</option>
                <option value="capDepartament">Cap de Departament</option>
            </select>
        </div>
        <div class="form-group">           
            <label for="email">Email</label>
            <input type="email" class="form-control" name="email"/>
        </div>
        <div class="form-group">           
            <label for="password">Contrasenya</label>
            <input type="password" class="form-control" name="password"/>
        </div>
        <button type="submit" class="btn btn-block btn-primary">Envia</button>
    </form>    
  </div>
</div>
<div class="p-6 bg-white border-b border-gray-200">
    <a href="<?php echo e(url('dashboard')); ?>">Torna al dashboard</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('disseny', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/empresa/resources/views/crear-users.blade.php ENDPATH**/ ?>