<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

<?php $__env->startSection('content'); ?>
    <br>
    <h1>Dades del client</h1>
    <div class="mt-5">
        <table class="table table-striped table-bordered table-hover">
            <thead class="thead-dark">
                <tr class="table-primary">
                    <th scope="col">CAMP</th>
                    <th scope="col">VALOR</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Matricula_auto</td>
                    <td><?php echo e($dades_auto->Matricula_auto); ?></td>
                </tr>
                <tr>
                    <td>Número de bastidor</td>
                    <td><?php echo e($dades_auto->Número_de_bastidor); ?></td>
                </tr>
                <tr>
                    <td>Marca</td>
                    <td><?php echo e($dades_auto->Marca); ?></td>
                </tr>
                <tr>
                    <td>Model</td>
                    <td><?php echo e($dades_auto->Model); ?></td>
                </tr>
                <tr>
                    <td>Color</td>
                    <td><?php echo e($dades_auto->Color); ?></td>
                </tr>
                <tr>
                    <td>Nombre de places</td>
                    <td><?php echo e($dades_auto->Nombre_de_places); ?></td>
                </tr>
                <tr>
                    <td>Nombre de portes</td>
                    <td><?php echo e($dades_auto->Nombre_de_portes); ?></td>
                </tr>
                <tr>
                    <td>Grandària del maleter</td>
                    <td><?php echo e($dades_auto->Grandària_del_maleter); ?></td>
                </tr>
                <tr>
                    <td>Tipus de combustible</td>
                    <td><?php echo e($dades_auto->Tipus_de_combustible); ?></td>
                </tr>
            </tbody>
        </table>
        <br>
        <div class="p-6 bg-white border-b border-gray-200">
        <?php if(Auth::user()->tipus == 'capDepartament'): ?>
        <a href="<?php echo e(url('dashboard')); ?>">Torna al dashboard</a>
    <?php else: ?>
        <a href="<?php echo e(url('dashboard-basic')); ?>">Torna al dashboard</a>
    <?php endif; ?>                   
        </div>
        <div class="p-6 bg-white border-b border-gray-200">
            <a href="<?php echo e(url('autos')); ?>">Torna a la llista</a>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('disseny', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/empresa/resources/views/mostra-cotxes.blade.php ENDPATH**/ ?>