
<?php $__env->startSection('content'); ?>
<h1>Llista d'empleats</h1>
<div class="mt-5">
<table class="table">
<thead>
<tr class="table-primary">
<td>tid</td>
<td>Nom</td>
<td>Cognoms</td>
<td>NIF</td>
<td>Data de naixement</td>
<td>Sexe</td>
<td>Adreça</td>
<td>Telèfon fixe</td>
<td>Telèfon mòbil</td>
<td>Email</td>
<td>Fotografia</td>
<td>Treball a distància</td>
<td>Tipus de contracte</td>
<td>Data de contractació</td>
<td>Categoria</td>
<td>Nom de la feina</td>
<td>Sou</td>
</tr>
</thead>
<tbody>
<?php $__currentLoopData = $dades_treballadors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $treb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($treb->tid); ?></td>
<td><?php echo e($treb->nom); ?></td>
<td><?php echo e($treb->cognoms); ?></td>
<td><?php echo e($treb->nif); ?></td>
<td><?php echo e($treb->data_naixement); ?></td>
<td><?php echo e($treb->sexe); ?></td>
<td><?php echo e($treb->adressa); ?></td>
<td><?php echo e($treb->tlf_fixe); ?></td>
<td><?php echo e($treb->tlf_mobil); ?></td>
<td><?php echo e($treb->email); ?></td>
<td><?php echo e($treb->fotografia); ?></td>
<td><?php echo e($treb->treball_distancia == "1" ? 'Sí':'No'); ?></td>
<td><?php echo e($treb->tipus_contracte); ?></td>
<td><?php echo e($treb->data_contractacio); ?></td>
<td><?php echo e($treb->categoria); ?></td>
<td><?php echo e($treb->nom_feina); ?></td>
<td><?php echo e($treb->sou); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('disseny', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/empresa/resources/views/llista.blade.php ENDPATH**/ ?>